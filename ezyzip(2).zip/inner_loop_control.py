import pandas as pd
from sim_model import reference_signal
from sim_model import aerodynamic_coef
import numpy as np

#parameters
g = 32.2
S = 0.55
W = 470
c = 0.75
Vt = 3150
m = W/g
Iyy = 182.5
M = 2.7
a = 340
V = M*a
q_ = 6132.8

def regressor_functions(x1,u):
    C2 =(q_ * S * c / (Iyy))
    phi_f2 = C2*np.array([0,0,0,0,x1**3,x1*np.abs(x1),x1,0])
    phi_g2 = C2*np.array([0,0,0,0,0,0,0,1])
    return np.array([phi_f2,phi_g2])

def command_filter(dt,x,x0):
    wn,damp = 20,0.7
    # Define the system matrices
    A = np.array([[0., 1], [-wn**2, -2*damp*wn]])
    B = np.array([[0], [wn**2]])
    x_dot = (A@x + (B@x0).reshape((2,1))).flatten()
    y1,y2 = x[0] + x_dot[0] * dt, x[1] + x_dot[1]*dt
    return y1[0],y2[0]


def CIBS_control(t,c1,c2,uncertainty):
    dt = t[1]-t[0]

    # tracking signal and derivatives
    yr = reference_signal(t)
    yr_dot = np.gradient(yr, dt)
    x1,x2,x3 = 0.,0.,0.
    x2c, x2c_dot = 0., 0.
    xi_1, xi_2 = 0., 0.
    u, u_dot = 0., 0.
    x2_dot = 0.
    x,y = 0.,0.

    columns = ["x1","x2","z1","z2","u","x","y"]
    df = pd.DataFrame(np.zeros((len(t),len(columns))),columns = columns,index = t)

    for index, t_i in enumerate(t):
        bz, bm, Cz, Cm = aerodynamic_coef(x1, M)
        f1,g1 = (q_ * S / (m * Vt)) * Cz , 1.
        f2,g2 = (q_ * S * c / (Iyy)) * Cm, (q_ * S * c / (Iyy)) * bm

        z1 = x1 - yr[index]
        z2 = x2 - x2c
        x1_dot = f1 + g1*x2

        #virtual control
        alpha = (-1/g1)*(c1*z1+f1+z2 - yr_dot[index])
        x2c_0 = alpha - xi_2

        #command filtering x
        x2c,x2c_dot = command_filter(dt,np.array([[x2c],[x2c_dot]]),[x2c_0])
        xi_1_dot = -c1*xi_1+(x2c-x2c_0)
        xi_1 = xi_1+xi_1_dot*dt


        #acceleration measurement
        x2_0 = (q_ * S / (m * Vt*Vt))*(Cz + bm*u)

        #control law
        du = -(1/g2)*(c2*z2+x2_0-x2c_dot+g1*z1)
        u = u+du
        x2_dot = x2_0 - c2*z2 - g1*z1 +((1+uncertainty)**-1)*uncertainty*(x2_dot-x2c_dot)

        #angle of attack x1, pitch rate x2 and pitch angle x3
        x1 = x1 + x1_dot*dt
        x2 = x2 + x2_dot*dt
        x3 = x3 + x2 * dt

        #MISSILE TRAJECTORY
        gamma = x3 - x1
        Vx, Vy = V * np.cos(gamma), V * np.sin(gamma)
        x, y = x + Vx * dt, y + Vy * dt
        df.loc[t_i,columns] = [x1,x2,z1,z2,u,x,y]

    df['yr'] = yr
    return df

def CABS_control(t,c1,c2,gamma):
    dt = t[1] - t[0]
    # tracking signal and derivatives
    yr = reference_signal(t)
    yr_dot = np.gradient(yr, dt)

    #initialise variables
    x1, x2, x3 = 0., 0., 0.
    x2c, x2c_dot = 0., 0.
    xi_1, xi_2 = 0., 0.
    u, u_dot = 0., 0.
    x,y = 0.,0.

    gamma_f2,gamma_g2 = gamma*np.ones((8,1)),gamma*np.ones((8,1))
    theta_hat_f2,theta_hat_g2 = np.ones((8,1)),np.ones((8,1))

    #initialise dataframe
    columns = ["x1","x2","z1","z2","u","theta_f2","theta_g2","x","y"]
    df = pd.DataFrame(np.zeros((len(t),len(columns))),columns = columns,index = t)

    for index, t_i in enumerate(t):
        #on-board aerodynamic model
        bz, bm, Cz, Cm = aerodynamic_coef(x1, M)
        f1_0,g1_0 = (q_ * S / (m * Vt)) * Cz , 1.
        f2_0,g2_0 = (q_ * S * c / (Iyy)) * Cm, (q_ * S * c / (Iyy)) * bm

        #regressor functions for uncertainties in aerodynamic model
        phi_f2, phi_g2 = regressor_functions(x1,u)

        #tracking error
        z1 = x1 - yr[index]
        #virtual control
        alpha_1 = -c1*z1-f1_0 + yr_dot[index]
        x2c_0 = alpha_1 - xi_2

        #command filtering x
        x2c,x2c_dot = command_filter(dt,np.array([[x2c],[x2c_dot]]),[x2c_0])
        xi_1_dot = -c1*xi_1+(x2c-x2c_0)
        xi_1 = xi_1+xi_1_dot*dt
        z1_bar = z1 - xi_1

        #command filtering u
        z2 = x2 - x2c
        u0 = (((g2_0+phi_g2@theta_hat_g2)**-1)*(-c2*z2-(g1_0)*z1_bar-f2_0-phi_f2@theta_hat_f2+x2c_dot))[0]
        u,u_dot = command_filter(dt,np.array([[u],[u_dot]]),[u0])
        xi_2_dot = -c2*xi_2 +(g2_0+phi_g2@theta_hat_g2)*(u-u0)
        xi_2 = xi_2 + xi_2_dot*dt
        z2_bar = z2 - xi_2

        #updating estimations and state values
        theta_hat_f2_dot = phi_f2@gamma_f2@[z2_bar]
        theta_hat_g2_dot = phi_g2@gamma_g2@[z2_bar*u]
        theta_hat_f2 = theta_hat_f2 + theta_hat_f2_dot*dt
        theta_hat_g2 = theta_hat_g2 + theta_hat_g2_dot*dt

        x1_dot = x2 + f1_0
        x2_dot = (f2_0 + phi_f2@theta_hat_f2+(g2_0+phi_g2@theta_hat_g2)*u)[0]
        x1 = x1 + x1_dot*dt
        x2 = x2 + x2_dot*dt
        x3 = x3 + x2 * dt

        #MISSILE TRAJECTORY
        gamma = x3 - x1
        Vx, Vy = V * np.cos(gamma), V * np.sin(gamma)
        x, y = x + Vx * dt, y + Vy * dt

        df.loc[t_i,columns] = x1,x2,z1,z2,u,theta_hat_f2[0,0],theta_hat_g2[0,0],x,y
    df.loc[:,'yr'] = yr
    return df