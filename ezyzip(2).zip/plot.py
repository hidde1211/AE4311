import matplotlib.pyplot as plt
import numpy as np
from inner_loop_control import CIBS_control

def CABS_plotting(df,c1,c2,gamma):
    fig, ax = plt.subplots(2, 2)
    fig.subplots_adjust(hspace=0.35)
    fig.suptitle(f"CABS controller with c1 = {c1} & c2 = {c2} & gamma = {gamma}")

    ax[0,0].plot(df.index.values, (180 / np.pi) *df.yr, label='tracking signal', linestyle = '--')
    ax[0,0].plot(df.index.values, (180 / np.pi) * df.x1, label='x1')
    ax[0,0].legend()
    ax[0,0].set_ylabel("angle of attack [deg]")
    ax[0,0].set_xlabel("time [sec]")

    df[['z1','z2']].plot(ax=ax[1,0])
    ax[1,0].legend()
    ax[1,0].set_ylabel("tracking error")
    ax[1,0].set_xlabel("time [sec]")

    ax[0,1].plot(df.index, (180 / np.pi) * df.u, label='u')
    ax[0,1].legend()
    ax[0,1].set_ylabel("elevator deflection [deg]")
    ax[0,1].set_xlabel("time [sec]")

    df[['theta_f2','theta_g2']].plot(ax=ax[1,1])

    ax[1,1].legend()
    ax[1,1].set_ylabel("estimate value [-]")
    ax[1,1].set_xlabel("time [sec]")


def CIBS_plotting(df,c1,c2,delta_g2):
    fig, ax = plt.subplots(2, 2)
    fig.subplots_adjust(hspace=0.35)
    fig.suptitle(f"IBS controller with c1 = {c1} & c2 = {c2} & uncertainty = {delta_g2*100} %")

    ax[0,0].plot(df.index.values, (180 / np.pi) *df.yr, label='tracking signal', linestyle = '--')
    ax[0,0].plot(df.index.values, (180 / np.pi) * df.x1, label='x1')
    ax[0,0].legend()
    ax[0,0].set_ylabel("angle of attack [deg]")
    ax[0,0].set_xlabel("time [sec]")

    df[['z1','z2']].plot(ax=ax[1,0])
    ax[1,0].legend()
    ax[1,0].set_ylabel("tracking error")
    ax[1,0].set_xlabel("time [sec]")

    ax[0,1].plot(df.index, (180 / np.pi) * df.u, label='u')
    ax[0,1].legend()
    ax[0,1].set_ylabel("elevator deflection [deg]")
    ax[0,1].set_xlabel("time [sec]")

    #df[['theta_f2','theta_g2']].plot(ax=ax[1,1])

    #ax[1,1].legend()
    #ax[1,1].set_ylabel("estimate value [-]")
    #ax[1,1].set_xlabel("time [sec]")


def CIBS_robustness_plot(t,c1,c2,errors):
    fig, ax = plt.subplots(2, 2)
    for error in errors:
        df = CIBS_control(t, c1, c2, error)
        ax[0,0].plot(df.index, (180/np.pi)*df.x1,label = f'x1 error = {error}')
        ax[1,0].plot(df.index, df.z1)
        ax[1,1].plot(df.index, df.z2)
        ax[0,1].plot(df.index, (180/np.pi)*df.u)

    ax[0,0].legend()

def trajectory_plot(df_CIBS,df_CABS):
    ax = plt.figure().add_subplot(projection='3d')
    ax.plot(df_CIBS.x,np.zeros(len(df_CIBS)),df_CIBS.y,label = 'CIBS')
    ax.plot(df_CABS.x,np.zeros(len(df_CABS)),df_CABS.y,label = 'CABS')
    ax.legend()





